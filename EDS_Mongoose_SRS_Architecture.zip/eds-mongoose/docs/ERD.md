# EDS Academy & Design Portal — Mermaid ERD

This intentionally shows the **32 physical collections** for the SRS's 29 conceptual entity groups, splitting the conceptual Roles/Permissions group into four collections. ObjectId `_id` is used in place of conceptual UUID IDs.

```mermaid
erDiagram
  USER ||--o{ USER_ROLE : assigned
  ROLE ||--o{ USER_ROLE : granted
  ROLE ||--o{ ROLE_PERMISSION : contains
  PERMISSION ||--o{ ROLE_PERMISSION : specifies
  COURSE ||--o{ MODULE : contains
  MODULE ||--o{ LESSON : contains
  COURSE ||--o{ BATCH : schedules
  USER ||--o{ INSTRUCTOR_ASSIGNMENT : teaches
  COURSE ||--o{ INSTRUCTOR_ASSIGNMENT : assigned_to
  BATCH o|--o{ INSTRUCTOR_ASSIGNMENT : scopes
  USER ||--o{ ENROLLMENT : enrolls
  COURSE ||--o{ ENROLLMENT : receives
  BATCH o|--o{ ENROLLMENT : cohort
  USER ||--o{ MODULE_ENTITLEMENT : owns
  MODULE ||--o{ MODULE_ENTITLEMENT : unlocks
  ORDER_ITEM o|--o{ MODULE_ENTITLEMENT : funds
  LESSON ||--o{ MEDIA_ASSET : versions
  USER ||--o{ LESSON_PROGRESS : tracks
  LESSON ||--o{ LESSON_PROGRESS : measured
  COURSE ||--o{ LIVE_SESSION : holds
  MODULE o|--o{ LIVE_SESSION : covers
  BATCH o|--o{ LIVE_SESSION : hosts
  USER ||--o{ DESIGN_CASE : submits
  USER o|--o{ DESIGN_CASE : designs
  DESIGN_CASE ||--o{ CASE_TOOTH : selects
  DESIGN_CASE ||--o{ CASE_ATTACHMENT : uploads
  DESIGN_CASE ||--o{ CASE_STATUS_HISTORY : transitions
  DESIGN_CASE ||--o{ DESIGN_DELIVERABLE : generates
  USER ||--o{ ORDER : purchases
  ORDER ||--|{ ORDER_ITEM : comprises
  ORDER ||--o{ PAYMENT : attempts
  PAYMENT ||--o{ PAYMENT_TRANSACTION : records
  PAYMENT ||--o{ MANUAL_TRANSFER_RECEIPT : claims
  CONFIGURATION_VERSION ||--o{ MODULE_DISCOUNT_TIER : defines
  CONFIGURATION_VERSION ||--o{ DESIGN_PRICING_RULE : defines
  USER ||--o{ NOTIFICATION : receives
  NOTIFICATION ||--o{ WHATSAPP_DELIVERY_LOG : dispatches
  USER ||--o{ NOTIFICATION_PREFERENCE : configures
  USER o|--o{ AUDIT_LOG : acts

  USER { ObjectId _id PK string emailNormalized UK string accountStatus }
  ROLE { ObjectId _id PK string name UK }
  PERMISSION { ObjectId _id PK string code UK }
  USER_ROLE { ObjectId user FK ObjectId role FK }
  ROLE_PERMISSION { ObjectId role FK ObjectId permission FK }
  COURSE { ObjectId _id PK string title string publicationStatus }
  MODULE { ObjectId course FK int sortOrder decimal unitPrice }
  LESSON { ObjectId module FK int sequenceNo ObjectId currentMediaAsset FK }
  BATCH { ObjectId course FK date startAt int capacity }
  INSTRUCTOR_ASSIGNMENT { ObjectId user FK ObjectId course FK ObjectId batch FK }
  ENROLLMENT { ObjectId user FK ObjectId course FK ObjectId batch FK }
  MODULE_ENTITLEMENT { ObjectId user FK ObjectId module FK ObjectId sourceOrderItem FK }
  LESSON_PROGRESS { ObjectId user FK ObjectId lesson FK int mediaVersion }
  LIVE_SESSION { ObjectId course FK ObjectId module FK ObjectId batch FK }
  MEDIA_ASSET { ObjectId lesson FK int mediaVersion string packagingStatus }
  DESIGN_CASE { ObjectId owner FK ObjectId assignedTechnician FK string status }
  CASE_TOOTH { ObjectId designCase FK string canonicalToothId }
  CASE_ATTACHMENT { ObjectId designCase FK string storageObjectKey }
  CASE_STATUS_HISTORY { ObjectId designCase FK int caseVersion }
  DESIGN_DELIVERABLE { ObjectId designCase FK int versionNo }
  ORDER { ObjectId buyer FK string orderDomain decimal finalTotal }
  ORDER_ITEM { ObjectId order FK ObjectId domainResourceId decimal lineTotal }
  PAYMENT { ObjectId order FK string paymentStatus decimal amount }
  PAYMENT_TRANSACTION { ObjectId payment FK string providerEventId }
  MANUAL_TRANSFER_RECEIPT { ObjectId payment FK string reviewState }
  CONFIGURATION_VERSION { string configDomain date effectiveFrom }
  MODULE_DISCOUNT_TIER { ObjectId version FK int minCount decimal discountPercent }
  DESIGN_PRICING_RULE { ObjectId version FK string currency decimal amountOrRate }
  NOTIFICATION { ObjectId targetUser FK string eventKey }
  WHATSAPP_DELIVERY_LOG { ObjectId notification FK string deliveryStatus }
  NOTIFICATION_PREFERENCE { ObjectId user FK string channel }
  AUDIT_LOG { ObjectId actor FK string actionCode }
```
