# EDS Academy & Design Portal — Mongoose architecture

**Source:** `EDS_Academy_Design_Portal_SRS_v1.0_Draft.docx` (EDS-SRS-001, 27 Oct 2026), particularly §3 and §4. The source is explicitly a **draft**. This repository implements its **29 conceptual entity groups as 32 collections**: the single conceptual RBAC group is normalized to `Role`, `Permission`, `UserRole` and `RolePermission`. All other entity groups map 1:1.

## Start

- Node.js 20+, MongoDB replica set, Mongoose 8.x.
- `npm install` and import models from `src/models/index.js`.
- Configure MongoDB connection outside the model layer. For production migrations create indexes explicitly using a controlled deploy step; set `autoIndex:false` on the connection.
- `node --check src/models/*.js` is a syntax check, not a database integration test. Integration and security tests are required before deployment.
- Full diagram: `docs/ERD.md`.

## Collection overview

| Domain | Collections | Purpose |
|---|---|---|
| Identity and security | User, Role, Permission, UserRole, RolePermission | Login principal, scoped RBAC grants |
| Academy | Course, Module, Lesson, Batch, InstructorAssignment, Enrollment, ModuleEntitlement, LessonProgress, LiveSession, MediaAsset | Content, cohorts, paid module grants, HLS metadata, progress |
| Design | DesignCase, CaseTooth, CaseAttachment, CaseStatusHistory, DesignDeliverable | Clinical case intake, canonical tooth mapping, protected uploads, QC and traceability |
| Finance | Order, OrderItem, Payment, PaymentTransaction, ManualTransferReceipt | Frozen quotes, verified settlement and manual payment review |
| Configuration | ConfigurationVersion, ModuleDiscountTier, DesignPricingRule | Effective-date business rules |
| Communication and compliance | Notification, WhatsAppDeliveryLog, NotificationPreference, AuditLog | Durable notification inbox, opt-in, delivery attempts, audit |

## Design decisions

1. **References vs embedding:** independently growing records use ObjectId relationships (payments, status history, attachments, order items, progress, lessons). Small, bounded change summaries and live-session schedule history are embedded. Binary media are never stored in MongoDB; store *opaque references* to private Cloudflare R2 objects.
2. **Money:** Mongoose `Decimal128` for prices, not floating-point `Number`. Convert to a validated decimal library (e.g., decimal.js) when calculating prices; never use JS float arithmetic. Currency is an uppercase three-letter code. Currency availability and scale remain TBD.
3. **Immutable commitments:** OrderItem prohibits model-instance subsequent saves, while financial events/status history/audit are append-only. **Important:** MongoDB collection permissions, write-service architecture, restricted raw database access and auditing must enforce immutability beyond Mongoose middleware. Order payment status may transition but committed totals must be write-protected in the service.
4. **Domain isolation:** An Academy paid order can grant only its snapshot-covered modules. A Design paid order can unlock only its approved case milestone. Domain-specific fulfillment requires verified payment processing in a transaction.
5. **Clinical privacy:** patientLabel, meetingUrl, storageObjectKey and credentialHash are `select:false` by default; explicit API-level ownership checks and signed object access are mandatory. `select:false` is not authorization.
6. **Dental notation:** `CaseTooth.canonicalToothId` stores *permanent-dentition FDI 11–48 canonical IDs*; the UI Universal/Palmer mapping is derived. Primary teeth are TBD.
7. **Retries and deduplication:** unique provider/merchant/event ID index stops repeated callback inserts; processing should be transactional. Successful payment-to-entitlement fulfillment must be idempotent. LessonProgress has unique user/lesson/media-version but event-level replay defense still needs a bounded durable ingestion mechanism or equivalent unique event-ID store.
8. **Missing object-level checks:** MongoDB has no foreign keys. Every domain service checks the existence and matching ancestry of refs before mutation (Course/Module/Lesson/Batch, Order/Item/Payment, Case/Attachment/Deliverable, etc.).
9. **Outbox:** SRS requires atomic state + fulfillment instruction or durable transactional outbox. The sample `transitionCase` atomically creates case state/history/inbox notification. Production Socket.io and WhatsApp publishing should use an idempotent worker/outbox. If delivery guarantees require a persistent outbox collection, approve it as an implementation support collection.
10. **Published configuration:** tiers and pricing rules are versioned; enforce non-overlapping effective intervals in transactional application logic, because MongoDB unique indexes cannot enforce date-range exclusion constraints.

## Important implementation obligations before launch

- Implement adaptive credential hashing in the identity service (argon2id/bcrypt), password policies, session/token revocation and account-status checks; never hash synchronously or accept client-generated hashes blindly.
- Enforce Role + Permission + scoped object ownership on **every** API request, media segment/key access, Socket.io room join and download. Seed an approved permission matrix. Role membership alone does not grant other users' clinical files.
- Protect case transitions with an explicit transition state machine, QC gate, and signed file release validation; sample `src/services/transitionCase.js` intentionally refuses terminal/QC-release transitions without the full workflow.
- For a committed order, validate all line items and payable totals server-side, snapshot applicable config versions, then commit atomically. Prevent cross-domain line mixing; use a verified gateway event or independently approved manual transfer before fulfilling.
- Use `mongoose.connection.transaction` with majority read/write concerns in a configured replica set. Audit that notification delivery and provider callbacks are idempotent, retryable and not visible before commit.
- Verify uploads by detected type, size, checksum, malware policy, and R2 object availability before setting `validated`. Never return bare object keys to customers.
- For MediaAsset, the raw HLS encryption secret lives in a secret manager/key service, **not** in the model. Store only an opaque `keyIdentifier`. Validate signed playlist, segment and key requests separately.
- Implement database-level role permissions/compartmentalization, encryption in transit/at rest, secrets management, backups and restoration tests, monitoring, rate limiting, and region-specific privacy/retention policies.

## Known assumptions and unresolved requirements from SRS §1.7

- **MongoDB deviation:** SRS's logical data layer is relational and proposes UUIDs; per request this is adapted to ObjectId references. No equivalence to database-enforced foreign keys is implied.
- **Draft lifecycle:** incomplete DesignCase draft allowed; fields become required once status is not `draft`.
- **Payment policy TBD:** partial/multiple successful payments, reversals, dispute/refund behavior, accepted methods/currencies/tax and design billing gate.
- **Course policy TBD:** whole-course pricing, future modules, access expiration, enrollment scope uniqueness and discounts above currently defined tiers.
- **QC policy TBD:** whether QC approval requires independent reviewer; assignment permissions, rejection/resubmission/cancellation/reopen transitions.
- **Video policy TBD:** completion watch threshold, media-version progress migration, HLS TTL/key rotations, file type/size, and malware/retention controls.
- **Consent and compliance TBD:** patient consent, patient label mandatory status, WhatsApp consent details, data residency, data minimization, erasure and audit retention.
- **Scheduling TBD:** exact batch capacity, overlap policies, timezone semantics and reminder offsets.
- **Pricing extension:** `DesignPricingRule.amountKind` is **an implementation assumption** needed to distinguish fixed money from percentage modifiers. `PaymentTransaction.merchantAccount` is an **implementation assumption** needed for SRS's provider+merchant+event deduplication index. `LessonProgress.mediaVersion` and `Notification.resourceType` make SRS-referenced scopes explicit.
- **Status enums:** terminal design states are provisional where SRS says completed vs ready-for-download is TBD; do not enable them without approving workflow.

## Recommended indexes and access patterns

Each model declares major unique and compound indexes. Especially important: `User.emailNormalized` unique; `(Module.course,sortOrder)` unique; `(Lesson.module,sequenceNo)` unique; `(CaseTooth.designCase,canonicalToothId)` unique; `(LessonProgress.user,lesson,mediaVersion)` unique; `(PaymentTransaction.provider,merchantAccount,providerEventId)` sparse-in-effect partial unique; `(CaseStatusHistory.designCase,caseVersion)` unique; `(DesignDeliverable.designCase,versionNo)` unique; `(Notification.targetUser,eventKey)` unique. High-traffic reads favor `(DesignCase.owner,status,createdAt)`, `(DesignCase.assignedTechnician,status,createdAt)`, `(Notification.targetUser,readAt,createdAt)` and `(Payment.order,paymentStatus)`.

Avoid unbounded population; paginate histories and order items, use projections/lean read paths, archive audit data according to approved retention policy and benchmark with representative production-sized data. Unique indexes prevent duplicates, **not** authorization, reference existence, or effective-time overlap.
