import mongoose from 'mongoose';
import { DesignCase, CaseStatusHistory, Notification } from '../models/index.js';

// Service-level transaction: authorization must be checked upstream and again
// before this call. MongoDB replica set/sharded transaction support required.
const ALLOWED = Object.freeze({
  draft: ['submitted'],
  submitted: ['reviewing'],
  reviewing: ['in_design'],
  in_design: ['quality_check'],
  quality_check: ['in_design', 'completed'],
  completed: ['ready_for_download'],
  ready_for_download: []
});

export async function transitionCase({ caseId, actorId, expectedVersion, toStatus, reason }) {
  return mongoose.connection.transaction(async (session) => {
    const existing = await DesignCase.findById(caseId).session(session);
    if (!existing) throw new Error('Case not found');
    if (!ALLOWED[existing.status]?.includes(toStatus)) throw new Error('Invalid workflow transition');
    // QC and release guards must be checked here in the domain service. Never
    // trust a client-supplied approval or payment flag.
    if (toStatus === 'completed' || toStatus === 'ready_for_download') {
      throw new Error('Invoke approved QC/release workflow with verified gates');
    }
    const nextVersion = expectedVersion + 1;
    const changed = await DesignCase.findOneAndUpdate(
      { _id: caseId, caseVersion: expectedVersion, status: existing.status },
      { $set: { status: toStatus }, $inc: { caseVersion: 1 } },
      { session, new: true, runValidators: true }
    );
    if (!changed) throw new Error('Concurrent update; retry after refresh');
    await CaseStatusHistory.create([{ designCase: caseId, actor: actorId,
      fromStatus: existing.status, toStatus, reason, caseVersion: nextVersion }], { session });
    await Notification.create([{ targetUser: existing.owner,
      eventKey: `case:${caseId}:version:${nextVersion}`, eventType: 'case_transition',
      resourceType: 'design_case', resourceId: caseId,
      safePayload: { status: toStatus } }], { session });
    return changed;
  });
}
