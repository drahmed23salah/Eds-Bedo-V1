import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({title:{type:String,required:true,trim:true,maxlength:250},description:{type:String,maxlength:10000},publicationStatus:{type:String,enum:['draft','published','archived'],default:'draft'},catalogPrice:{type:D,default:'0'},currency:{type:String,uppercase:true,match:/^[A-Z]{3}$/},accessPolicyVersion:String});
s.index({publicationStatus:1,updatedAt:-1});
export default mongoose.models.Course || mongoose.model('Course',s);
