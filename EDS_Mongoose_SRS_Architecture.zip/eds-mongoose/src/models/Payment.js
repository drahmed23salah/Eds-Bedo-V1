import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({order:{type:O,ref:'Order',required:true},method:{type:String,enum:['paymob','paypal','manual'],required:true},paymentStatus:{type:String,enum:['pending','awaiting_verification','succeeded','failed','reversed'],default:'pending'},amount:{type:D,required:true},currency:{type:String,required:true,uppercase:true,match:/^[A-Z]{3}$/},verifiedAt:Date,verifiedBy:{type:O,ref:'User'},providerReference:String});
s.index({order:1,paymentStatus:1});s.index({method:1,providerReference:1},{unique:true,partialFilterExpression:{providerReference:{$type:'string'}}});
export default mongoose.models.Payment || mongoose.model('Payment',s);
