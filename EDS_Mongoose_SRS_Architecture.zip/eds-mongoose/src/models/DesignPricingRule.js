import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({restorationCriterion:String,materialCriterion:String,modifierType:{type:String,enum:['none','rush','pink'],default:'none'},amountOrRate:{type:D,required:true},amountKind:{type:String,enum:['fixed','percent'],required:true},currency:{type:String,required:true,uppercase:true,match:/^[A-Z]{3}$/},effectiveFrom:{type:Date,required:true},effectiveUntil:Date,version:{type:O,ref:'ConfigurationVersion',required:true},changedBy:{type:O,ref:'User',required:true}});
s.index({version:1,restorationCriterion:1,materialCriterion:1,modifierType:1,currency:1});
export default mongoose.models.DesignPricingRule || mongoose.model('DesignPricingRule',s);
