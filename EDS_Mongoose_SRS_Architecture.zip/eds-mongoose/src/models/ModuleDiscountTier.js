import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({scope:{type:String,required:true},minCount:{type:Number,required:true,min:1},maxCount:{type:Number,min:1},discountPercent:{type:D,required:true},effectiveFrom:{type:Date,required:true},effectiveUntil:Date,version:{type:O,ref:'ConfigurationVersion',required:true},changedBy:{type:O,ref:'User',required:true}});
s.index({scope:1,version:1,minCount:1},{unique:true});s.pre('validate',function(next){if(this.maxCount!=null&&this.maxCount<this.minCount)this.invalidate('maxCount','Must be >= minCount');next();});
export default mongoose.models.ModuleDiscountTier || mongoose.model('ModuleDiscountTier',s);
