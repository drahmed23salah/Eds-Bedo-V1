import mongoose from 'mongoose';
export const { Schema } = mongoose;
export const O = Schema.Types.ObjectId;
export const D = Schema.Types.Decimal128;
export function makeSchema(definition) {
  return new Schema(definition, { timestamps: true, strict: 'throw', versionKey: '__v' });
}
export function immutableAppendOnly(schema) {
  schema.pre('save', function(next) { if (!this.isNew) this.invalidate('_id', 'Append-only record'); next(); });
  for (const op of ['updateOne', 'updateMany', 'findOneAndUpdate', 'replaceOne', 'findOneAndReplace', 'deleteOne', 'deleteMany', 'findOneAndDelete']) {
    schema.pre(op, function(next) { next(new Error('Append-only collection: operation prohibited')); });
  }
}
