import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({actor:{type:O,ref:'User'},actionCode:{type:String,required:true},resourceType:{type:String,required:true},resourceId:O,outcome:{type:String,enum:['allowed','denied','failed'],required:true},eventAt:{type:Date,default:Date.now},requestCorrelationId:String,redactedChangeSummary:Schema.Types.Mixed});
s.index({actionCode:1,eventAt:-1});s.index({resourceType:1,resourceId:1,eventAt:-1});s.index({requestCorrelationId:1});
immutableAppendOnly(s);
export default mongoose.models.AuditLog || mongoose.model('AuditLog',s);
