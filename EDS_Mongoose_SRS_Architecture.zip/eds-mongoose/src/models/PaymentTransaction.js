import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({payment:{type:O,ref:'Payment',required:true},provider:{type:String,enum:['paymob','paypal','manual'],required:true},merchantAccount:{type:String,required:true},providerEventId:String,externalReference:String,eventType:{type:String,enum:['initiated','succeeded','failed','reversed','pending'],required:true},amount:{type:D,required:true},currency:{type:String,required:true,uppercase:true,match:/^[A-Z]{3}$/},verificationResult:{type:String,enum:['verified','rejected','pending'],default:'pending'},receivedAt:{type:Date,default:Date.now},redactedPayloadPointer:String});
s.index({provider:1,merchantAccount:1,providerEventId:1},{unique:true,partialFilterExpression:{providerEventId:{$type:'string'}}});s.index({payment:1,receivedAt:-1});
immutableAppendOnly(s);
export default mongoose.models.PaymentTransaction || mongoose.model('PaymentTransaction',s);
