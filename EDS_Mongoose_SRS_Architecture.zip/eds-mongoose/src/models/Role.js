import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({name:{type:String,required:true,trim:true,lowercase:true},description:{type:String,maxlength:300}});
s.index({name:1},{unique:true});
export default mongoose.models.Role || mongoose.model('Role',s);
