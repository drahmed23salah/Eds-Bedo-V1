import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({designCase:{type:O,ref:'DesignCase',required:true},uploader:{type:O,ref:'User',required:true},fileRole:{type:String,enum:['scan','clinical_photo','other'],required:true},originalFilename:{type:String,required:true,maxlength:255},detectedMimeType:{type:String,required:true},storageObjectKey:{type:String,required:true,select:false},checksum:String,uploadStatus:{type:String,enum:['initiated','quarantined','validated','rejected'],default:'initiated'},bytes:{type:Number,required:true,min:0},versionNo:{type:Number,default:1,min:1}});
s.index({storageObjectKey:1},{unique:true});s.index({designCase:1,uploadStatus:1});
export default mongoose.models.CaseAttachment || mongoose.model('CaseAttachment',s);
