import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({notification:{type:O,ref:'Notification',required:true},user:{type:O,ref:'User',required:true},templateName:{type:String,required:true},consentVersion:{type:String,required:true},providerMessageId:String,deliveryStatus:{type:String,enum:['queued','sent','delivered','read','failed'],default:'queued'},attemptCount:{type:Number,default:0,min:0},lastAttemptAt:Date,errorCode:String});
s.index({providerMessageId:1},{unique:true,partialFilterExpression:{providerMessageId:{$type:'string'}}});s.index({deliveryStatus:1,lastAttemptAt:1});
export default mongoose.models.WhatsAppDeliveryLog || mongoose.model('WhatsAppDeliveryLog',s);
