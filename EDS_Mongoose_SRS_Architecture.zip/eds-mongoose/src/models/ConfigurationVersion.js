import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({configDomain:{type:String,enum:['discount','design_price','other'],required:true},effectiveFrom:{type:Date,required:true},effectiveUntil:Date,createdBy:{type:O,ref:'User',required:true},changeReason:String,publishedAt:Date});
s.index({configDomain:1,effectiveFrom:-1});
export default mongoose.models.ConfigurationVersion || mongoose.model('ConfigurationVersion',s);
