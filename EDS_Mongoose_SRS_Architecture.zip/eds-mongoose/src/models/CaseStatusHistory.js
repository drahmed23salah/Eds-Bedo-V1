import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({designCase:{type:O,ref:'DesignCase',required:true},actor:{type:O,ref:'User',required:true},fromStatus:String,toStatus:{type:String,required:true},reason:String,eventTime:{type:Date,default:Date.now},caseVersion:{type:Number,required:true,min:1}});
s.index({designCase:1,caseVersion:1},{unique:true});s.index({designCase:1,eventTime:1});
immutableAppendOnly(s);
export default mongoose.models.CaseStatusHistory || mongoose.model('CaseStatusHistory',s);
