import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({course:{type:O,ref:'Course',required:true},module:{type:O,ref:'Module'},batch:{type:O,ref:'Batch'},provider:{type:String,enum:['zoom','meet','teams'],required:true},meetingUrl:{type:String,required:true,select:false,match:/^https:\/\//},startAt:{type:Date,required:true},endAt:{type:Date,required:true},timezone:{type:String,required:true},status:{type:String,enum:['scheduled','rescheduled','canceled'],default:'scheduled'},scheduleVersion:{type:Number,default:1,min:1},scheduleHistory:[{startAt:Date,endAt:Date,status:String,changedAt:Date}]});
s.index({batch:1,startAt:1});s.index({course:1,startAt:1});s.pre('validate',function(next){if(this.startAt&&this.endAt&&this.endAt<=this.startAt)this.invalidate('endAt','Must follow startAt');next();});
export default mongoose.models.LiveSession || mongoose.model('LiveSession',s);
