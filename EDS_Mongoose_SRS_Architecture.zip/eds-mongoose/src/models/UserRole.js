import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({user:{type:O,ref:'User',required:true},role:{type:O,ref:'Role',required:true},scopeDescriptor:{type:String,maxlength:240},assignedBy:{type:O,ref:'User',required:true},validFrom:{type:Date,default:Date.now},validUntil:Date});
s.index({user:1,role:1,scopeDescriptor:1},{unique:true});
export default mongoose.models.UserRole || mongoose.model('UserRole',s);
