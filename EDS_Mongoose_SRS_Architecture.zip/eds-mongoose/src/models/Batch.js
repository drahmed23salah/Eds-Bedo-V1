import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({course:{type:O,ref:'Course',required:true},batchName:{type:String,required:true,trim:true,maxlength:200},startAt:{type:Date,required:true},endAt:Date,capacity:{type:Number,min:1},status:{type:String,enum:['planned','open','closed','completed','canceled'],default:'planned'}});
s.index({course:1,startAt:1});s.pre('validate',function(next){if(this.endAt&&this.startAt&&this.endAt<=this.startAt)this.invalidate('endAt','Must follow startAt');next();});
export default mongoose.models.Batch || mongoose.model('Batch',s);
