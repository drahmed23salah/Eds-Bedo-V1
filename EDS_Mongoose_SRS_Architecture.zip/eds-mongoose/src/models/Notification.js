import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({targetUser:{type:O,ref:'User',required:true},eventKey:{type:String,required:true},eventType:{type:String,required:true},resourceType:{type:String,required:true},resourceId:{type:O,required:true},safePayload:{type:Schema.Types.Mixed,required:true},readAt:Date});
s.index({targetUser:1,eventKey:1},{unique:true});s.index({targetUser:1,readAt:1,createdAt:-1});
export default mongoose.models.Notification || mongoose.model('Notification',s);
