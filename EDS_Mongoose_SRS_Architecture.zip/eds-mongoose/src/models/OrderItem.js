import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({order:{type:O,ref:'Order',required:true},itemType:{type:String,enum:['module','course','design_service','modifier'],required:true},domainResourceId:{type:O,required:true},quantity:{type:D,required:true},unitPrice:{type:D,required:true},discountAmount:{type:D,required:true},lineTotal:{type:D,required:true},ruleSnapshot:{type:Schema.Types.Mixed,required:true}});
s.index({order:1});s.index({domainResourceId:1,itemType:1});
s.pre('save',function(next){if(!this.isNew)this.invalidate('_id','Committed order items are immutable');next();});
export default mongoose.models.OrderItem || mongoose.model('OrderItem',s);
