import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({course:{type:O,ref:'Course',required:true},title:{type:String,required:true,trim:true,maxlength:250},sortOrder:{type:Number,required:true,min:0},publicationStatus:{type:String,enum:['draft','published','archived'],default:'draft'},unitPrice:{type:D,default:'0'},saleEligible:{type:Boolean,default:false},contentVersion:{type:Number,default:1,min:1}});
s.index({course:1,sortOrder:1},{unique:true});s.index({course:1,publicationStatus:1});
export default mongoose.models.Module || mongoose.model('Module',s);
