import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({user:{type:O,ref:'User',required:true},course:{type:O,ref:'Course',required:true},batch:{type:O,ref:'Batch'},enrollmentStatus:{type:String,enum:['pending','active','completed','withdrawn'],default:'pending'},sourceOrder:{type:O,ref:'Order'},completedAt:Date});
s.index({user:1,course:1,batch:1},{unique:true});s.index({batch:1,enrollmentStatus:1});
export default mongoose.models.Enrollment || mongoose.model('Enrollment',s);
