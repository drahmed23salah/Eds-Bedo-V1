import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({user:{type:O,ref:'User',required:true},module:{type:O,ref:'Module',required:true},sourceOrderItem:{type:O,ref:'OrderItem'},grantType:{type:String,enum:['module','course','admin'],required:true},status:{type:String,enum:['active','expired','revoked'],default:'active'},validFrom:{type:Date,default:Date.now},validUntil:Date,policyVersion:String});
s.index({user:1,module:1,status:1,validFrom:1,validUntil:1});s.index({user:1,module:1,sourceOrderItem:1,grantType:1},{unique:true,partialFilterExpression:{sourceOrderItem:{$exists:true}}});
export default mongoose.models.ModuleEntitlement || mongoose.model('ModuleEntitlement',s);
