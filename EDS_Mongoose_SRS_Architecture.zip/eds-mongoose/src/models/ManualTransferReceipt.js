import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({payment:{type:O,ref:'Payment',required:true},submittedBy:{type:O,ref:'User',required:true},storageObjectKey:{type:String,required:true,select:false},claimedReference:String,claimedAmount:{type:D,required:true},reviewState:{type:String,enum:['pending','approved','rejected'],default:'pending'},reviewer:{type:O,ref:'User'},reviewReason:String,reviewedAt:Date});
s.index({storageObjectKey:1},{unique:true});s.index({reviewState:1,createdAt:1});s.pre('validate',function(next){if(this.reviewState==='rejected'&&!this.reviewReason)this.invalidate('reviewReason','Required for rejection');if(this.reviewState!=='pending'&&(!this.reviewer||!this.reviewedAt))this.invalidate('reviewer','Reviewer and time required');next();});
export default mongoose.models.ManualTransferReceipt || mongoose.model('ManualTransferReceipt',s);
