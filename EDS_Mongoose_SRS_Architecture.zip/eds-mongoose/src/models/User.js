import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({emailNormalized:{type:String,required:true,lowercase:true,trim:true,match:/^[^\s@]+@[^\s@]+\.[^\s@]+$/},displayName:{type:String,required:true,trim:true,maxlength:160},credentialHash:{type:String,required:true,select:false},accountStatus:{type:String,enum:['pending','active','suspended','deactivated'],default:'pending'},phoneE164:{type:String,match:/^\+[1-9]\d{7,14}$/}});
s.index({emailNormalized:1},{unique:true});s.index({accountStatus:1});
export default mongoose.models.User || mongoose.model('User',s);
