import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({user:{type:O,ref:'User',required:true},channel:{type:String,enum:['in_app','whatsapp'],required:true},consentStatus:{type:String,enum:['opted_in','opted_out','not_requested'],default:'not_requested'},consentAt:Date,consentSource:String,policyVersion:String});
s.index({user:1,channel:1},{unique:true});
export default mongoose.models.NotificationPreference || mongoose.model('NotificationPreference',s);
