import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({role:{type:O,ref:'Role',required:true},permission:{type:O,ref:'Permission',required:true}});
s.index({role:1,permission:1},{unique:true});
export default mongoose.models.RolePermission || mongoose.model('RolePermission',s);
