import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({user:{type:O,ref:'User',required:true},lesson:{type:O,ref:'Lesson',required:true},mediaVersion:{type:Number,required:true,min:1},resumeSecond:{type:Number,default:0,min:0},watchEvidence:{type:Schema.Types.Mixed},completionStatus:{type:String,enum:['in_progress','completed'],default:'in_progress'},criteriaVersion:{type:String,required:true},lastEventId:String});
s.index({user:1,lesson:1,mediaVersion:1},{unique:true});s.index({user:1,updatedAt:-1});
export default mongoose.models.LessonProgress || mongoose.model('LessonProgress',s);
