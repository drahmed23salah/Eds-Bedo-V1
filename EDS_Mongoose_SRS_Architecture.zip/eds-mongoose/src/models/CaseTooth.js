import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({designCase:{type:O,ref:'DesignCase',required:true},canonicalToothId:{type:String,required:true,match:/^(1[1-8]|2[1-8]|3[1-8]|4[1-8])$/},sourceNotation:{type:String,enum:['fdi','universal','palmer']}});
s.index({designCase:1,canonicalToothId:1},{unique:true});
export default mongoose.models.CaseTooth || mongoose.model('CaseTooth',s);
