import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({module:{type:O,ref:'Module',required:true},title:{type:String,required:true,maxlength:250},lessonType:{type:String,enum:['video','other'],default:'video'},sequenceNo:{type:Number,required:true,min:0},currentMediaAsset:{type:O,ref:'MediaAsset'},publishState:{type:String,enum:['draft','ready','published','archived'],default:'draft'},durationSeconds:{type:Number,min:0}});
s.index({module:1,sequenceNo:1},{unique:true});s.index({module:1,publishState:1});
export default mongoose.models.Lesson || mongoose.model('Lesson',s);
