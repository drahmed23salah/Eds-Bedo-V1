import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({buyer:{type:O,ref:'User',required:true},orderDomain:{type:String,enum:['academy','design'],required:true},orderStatus:{type:String,enum:['draft','pending','paid','canceled','failed'],default:'draft'},currency:{type:String,required:true,uppercase:true,match:/^[A-Z]{3}$/},subtotal:{type:D,required:true},discountTotal:{type:D,required:true},finalTotal:{type:D,required:true},quoteVersion:{type:String,required:true},committedAt:{type:Date,required:true}});
s.index({buyer:1,createdAt:-1});s.index({orderDomain:1,orderStatus:1,createdAt:-1});
export default mongoose.models.Order || mongoose.model('Order',s);
