import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({user:{type:O,ref:'User',required:true},course:{type:O,ref:'Course',required:true},batch:{type:O,ref:'Batch'},assignmentRole:{type:String,enum:['instructor','co_instructor'],required:true},validFrom:{type:Date,default:Date.now},validUntil:Date});
s.index({user:1,course:1,batch:1,assignmentRole:1});
export default mongoose.models.InstructorAssignment || mongoose.model('InstructorAssignment',s);
