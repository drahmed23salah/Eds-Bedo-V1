import mongoose from 'mongoose';
import { Schema, O, D, makeSchema, immutableAppendOnly } from './_shared.js';
const s = makeSchema({lesson:{type:O,ref:'Lesson',required:true},sourceObjectKey:{type:String,required:true,select:false},hlsManifestKey:{type:String,select:false},keyIdentifier:{type:String,select:false},packagingStatus:{type:String,enum:['uploaded','processing','ready','failed'],default:'uploaded'},mediaVersion:{type:Number,required:true,min:1},durationSeconds:{type:Number,min:0}});
s.index({lesson:1,mediaVersion:1},{unique:true});s.index({packagingStatus:1,createdAt:1});s.index({sourceObjectKey:1},{unique:true});
export default mongoose.models.MediaAsset || mongoose.model('MediaAsset',s);
